package com.nexa.app

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity

/**
 * Minimal launcher activity. In the full Flutter build this is replaced by
 * FlutterActivity; this native-only build keeps a plain button that sends
 * the user to Settings to manually enable NexaAccessibilityService, since
 * Android never allows an app to self-enable that permission.
 */
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }
        val enableButton = Button(this).apply {
            text = "Enable Nexa Accessibility Service"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        layout.addView(enableButton)
        setContentView(layout)
    }
}
