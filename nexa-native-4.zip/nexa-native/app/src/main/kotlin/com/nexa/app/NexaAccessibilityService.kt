package com.nexa.app

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.hardware.camera2.CameraManager
import android.telecom.TelecomManager
import android.view.accessibility.AccessibilityEvent
import android.provider.ContactsContract
import android.database.Cursor

/**
 * Privileged action executor. Every method here is only invoked AFTER the
 * Flutter layer confirms the voice-biometric gate passed for this utterance —
 * this service does not itself re-check identity, so never expose these
 * methods on a channel that isn't gated upstream.
 *
 * The user must manually enable this service:
 * Settings > Accessibility > Nexa > On (Android does not allow silent
 * self-enable, by design).
 */
class NexaAccessibilityService : AccessibilityService() {

    private val whitelistedActions = setOf(
        "flashlight_on", "flashlight_off", "answer_call", "end_call", "search_contact"
    )

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Reserved for future context-aware actions (e.g. reading foreground app
        // to disambiguate "scroll down" commands). Intentionally minimal for now.
    }

    override fun onInterrupt() {}

    fun execute(action: String, params: Map<String, Any?>): Boolean {
        if (action !in whitelistedActions) return false
        return when (action) {
            "flashlight_on" -> setFlashlight(true)
            "flashlight_off" -> setFlashlight(false)
            "answer_call" -> answerCall()
            "end_call" -> endCall()
            "search_contact" -> searchContact(params["name"] as? String ?: "") != null
            else -> false
        }
    }

    private fun setFlashlight(on: Boolean): Boolean {
        return try {
            val cameraManager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = cameraManager.cameraIdList.firstOrNull {
                cameraManager.getCameraCharacteristics(it)
                    .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return false
            cameraManager.setTorchMode(cameraId, on)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun answerCall(): Boolean {
        return try {
            val telecomManager = getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            telecomManager.acceptRingingCall()
            true
        } catch (e: SecurityException) {
            // ANSWER_PHONE_CALLS permission missing/not granted at runtime.
            false
        }
    }

    private fun endCall(): Boolean {
        // Requires either MODIFY_PHONE_STATE (system apps only) or, for a
        // third-party app, driving this through this AccessibilityService's
        // ability to perform a global action / simulate the hardware button —
        // there is no public SDK call for third-party call termination.
        return try {
            performGlobalAction(GLOBAL_ACTION_BACK) // placeholder: replace with
            // an InCallService-based hangup for a real implementation.
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun searchContact(name: String): String? {
        if (name.isBlank()) return null
        val cursor: Cursor? = contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"),
            null
        )
        cursor?.use {
            if (it.moveToFirst()) {
                return it.getString(it.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER))
            }
        }
        return null
    }
}
